﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;



namespace Coutry
{
    class Commad
    {
        public void GetAllInformationFromApi()
        {
            using (var webClient1 = new HttpClient())
            {


                string content1 = webClient1.GetAsync("https://jsonvat.com/").Result.Content.ReadAsStringAsync().Result;

                var xs = JsonConvert.DeserializeObject<Rootobject>(content1);

                
            }
        }

        string directory = @"Server:(localdb)\mssqllocaldb; Database = Eurotaxes";

        public void PopulateCountries(Rootobject xs)
        {
            foreach (var item in xs.rates)
            {
                string sql = @"INSERT INTO Countrynames(Country)
                            VALUES (@name)";

                using (SqlConnection connection = new SqlConnection(directory))
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    connection.Open();
                    command.Parameters.Add(new SqlParameter("@name", item.name));
                    command.ExecuteNonQuery();
                }
            }
        }

        public void PupulateVAT(Rootobject xs)
        {
            foreach (var item in xs.rates)
            {
                string sql = @"INSERT INTO VATInformation(Standard, Reduced, Reduced1, Reduced2, Super_reduced, parking, taxdate)
                            VALUES (@standard, @reduced, @reduced1, @reduced2, @superreduced, @parking, @date)";

                using (SqlConnection connection = new SqlConnection(directory))
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    connection.Open();
                    command.Parameters.Add("@standard", standard);
                    command.Parameters.Add("@Reduced", reduced);
                    command.Parameters.Add("@Reduced1", reducedOne);
                    command.Parameters.Add("@Reduced2", reducedTwo);
                    command.Parameters.Add("@parking", parking);
                    command.Parameters.Add("@superreduced", superReduced);
                    command.Parameters.Add("@date", fromDate);
                    command.ExecuteNonQuery();
                }


            }
        }
    }
}

