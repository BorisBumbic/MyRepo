﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmprovCheckpoint_2
{
    public class Furniture
    {
        public string name { get; set; }
        public int price { get; set; }
    }
}
