﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gnomecheckpoint
{
    class Gnome
    {
        public int id { get; set; }
        public string name { get; set; }
        public string beard { get; set; }
        public string alignment { get; set; }
        public int temperament { get; set; }
        public string race { get; set; }

    }
}
